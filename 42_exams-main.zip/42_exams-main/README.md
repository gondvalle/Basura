# 42tests-exams
evals testers and mock exams
